CMakeFiles/OpkgManagerplugin.dir/OpkgManagerplugin_autogen/EWIEGA46WW/qrc_resources.cpp.o: \
 /data/dev/utils/opkg-manager/src/qmlplugin/build-armhf/OpkgManagerplugin_autogen/EWIEGA46WW/qrc_resources.cpp \
 /usr/arm-linux-gnueabihf/include/stdc-predef.h
