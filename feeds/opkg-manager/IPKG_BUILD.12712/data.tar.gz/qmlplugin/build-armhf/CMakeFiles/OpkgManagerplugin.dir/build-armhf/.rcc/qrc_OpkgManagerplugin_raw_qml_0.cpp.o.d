CMakeFiles/OpkgManagerplugin.dir/build-armhf/.rcc/qrc_OpkgManagerplugin_raw_qml_0.cpp.o: \
 /data/dev/utils/opkg-manager/src/qmlplugin/build-armhf/.rcc/qrc_OpkgManagerplugin_raw_qml_0.cpp \
 /usr/arm-linux-gnueabihf/include/stdc-predef.h
