file(REMOVE_RECURSE
  "CMakeFiles/OpkgManagerplugin_qmllint"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/OpkgManagerplugin_qmllint.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
