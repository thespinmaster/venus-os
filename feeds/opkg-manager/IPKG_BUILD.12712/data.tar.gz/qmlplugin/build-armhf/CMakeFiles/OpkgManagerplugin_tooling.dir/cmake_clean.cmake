file(REMOVE_RECURSE
  "resources/OpkgEditBoxLargeText.qml"
  "resources/OpkgHeaderDescriptionItem.qml"
  "resources/OpkgObjectCustomOverviewPages.qml"
  "resources/OpkgPageSettingsCustomMenus.qml"
  "resources/OpkgPageSettingsSubMenu.qml"
  "resources/PageSettingsOpkg.qml"
  "resources/PageSettingsOpkgFeeds.qml"
  "resources/PageSettingsOpkgPackageInstall.qml"
  "resources/PageSettingsOpkgPackages.qml"
  "resources/test.qml"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/OpkgManagerplugin_tooling.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
