#include <QtQml/qqmlprivate.h>
#include <QtCore/qdir.h>
#include <QtCore/qurl.h>
#include <QtCore/qhash.h>
#include <QtCore/qstring.h>

namespace QmlCacheGeneratedCode {
namespace _0x5f_OpkgManager_resources_test_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_OpkgEditBoxLargeText_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_OpkgHeaderDescriptionItem_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_OpkgObjectCustomOverviewPages_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_OpkgPageSettingsCustomMenus_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_OpkgPageSettingsSubMenu_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_PageSettingsOpkg_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_PageSettingsOpkgFeeds_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_PageSettingsOpkgPackageInstall_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}
namespace _0x5f_OpkgManager_resources_PageSettingsOpkgPackages_qml { 
    extern const unsigned char qmlData[];
    extern const QQmlPrivate::AOTCompiledFunction aotBuiltFunctions[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), &aotBuiltFunctions[0], nullptr
    };
}

}
namespace {
struct Registry {
    Registry();
    ~Registry();
    QHash<QString, const QQmlPrivate::CachedQmlUnit*> resourcePathToCachedUnit;
    static const QQmlPrivate::CachedQmlUnit *lookupCachedUnit(const QUrl &url);
};

Q_GLOBAL_STATIC(Registry, unitRegistry)


Registry::Registry() {
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/test.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_test_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/OpkgEditBoxLargeText.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_OpkgEditBoxLargeText_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/OpkgHeaderDescriptionItem.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_OpkgHeaderDescriptionItem_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/OpkgObjectCustomOverviewPages.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_OpkgObjectCustomOverviewPages_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/OpkgPageSettingsCustomMenus.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_OpkgPageSettingsCustomMenus_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/OpkgPageSettingsSubMenu.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_OpkgPageSettingsSubMenu_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/PageSettingsOpkg.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_PageSettingsOpkg_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/PageSettingsOpkgFeeds.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_PageSettingsOpkgFeeds_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/PageSettingsOpkgPackageInstall.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_PageSettingsOpkgPackageInstall_qml::unit);
    resourcePathToCachedUnit.insert(QStringLiteral("/OpkgManager/resources/PageSettingsOpkgPackages.qml"), &QmlCacheGeneratedCode::_0x5f_OpkgManager_resources_PageSettingsOpkgPackages_qml::unit);
    QQmlPrivate::RegisterQmlUnitCacheHook registration;
    registration.structVersion = 0;
    registration.lookupCachedQmlUnit = &lookupCachedUnit;
    QQmlPrivate::qmlregister(QQmlPrivate::QmlUnitCacheHookRegistration, &registration);
}

Registry::~Registry() {
    QQmlPrivate::qmlunregister(QQmlPrivate::QmlUnitCacheHookRegistration, quintptr(&lookupCachedUnit));
}

const QQmlPrivate::CachedQmlUnit *Registry::lookupCachedUnit(const QUrl &url) {
    if (url.scheme() != QLatin1String("qrc"))
        return nullptr;
    QString resourcePath = QDir::cleanPath(url.path());
    if (resourcePath.isEmpty())
        return nullptr;
    if (!resourcePath.startsWith(QLatin1Char('/')))
        resourcePath.prepend(QLatin1Char('/'));
    return unitRegistry()->resourcePathToCachedUnit.value(resourcePath, nullptr);
}
}
int QT_MANGLE_NAMESPACE(qInitResources_qmlcache_OpkgManagerplugin)() {
    ::unitRegistry();
    return 1;
}
Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_qmlcache_OpkgManagerplugin))
int QT_MANGLE_NAMESPACE(qCleanupResources_qmlcache_OpkgManagerplugin)() {
    return 1;
}
