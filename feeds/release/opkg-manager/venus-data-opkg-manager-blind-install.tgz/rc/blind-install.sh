#!/bin/bash

declare log_path=/var/log/opkg-manager/
declare log=$log_path/blind-install.log

if [[ ! -d "$log_path" ]]; then
	mkdir -p "$log_path"
fi

exec > "$log" 2>&1
echo "blind-install opkg-manager"

if opkg list-installed opkg-manager; then
  echo "Already installed, nothing to do"
  exit 0
fi

echo "Running opkg-manager bind install"

mount -o remount,rw /
/opt/victronenergy/swupdate-scripts/resize2fs.sh

local opkg_url="https://thespinmaster.github.io/venus-os-addons/feeds/release/opkg-manager/opkg-manager-latest.ipk"

echo "installing- opkg-manager"

opkg install "$opkg_url" && {
  
  local install_list=$(find /run/media -mindepth 2 -maxdepth 2 -type f \
    -name 'venus-data-opkg-manager-blind-install.list' -print -quit)
  
  if [[ -f "$install_list" ]]; then
    echo "Installing additional packages from $install_list"

    mapfile -t pkgs < <(sed -e 's/[[:space:]]*#.*$//' -e '/^[[:space:]]*$/d' "$install_list")

    if ((${#pkgs[@]})); then
      opkg install "${pkgs[@]}"
    else
      echo "No packages listed in $install_list"
    fi
  fi
}


rm -f "${BASH_SOURCE[0]}"
echo "Done"